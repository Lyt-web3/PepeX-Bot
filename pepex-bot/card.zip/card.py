"""PepeX card generator. Put this file in your pepex-bot folder.

Run `python card.py` to render every style as a PNG so you can compare them.
"""
import math

from PIL import Image, ImageChops, ImageDraw, ImageFilter, ImageFont, ImageOps

W, H = 1200, 630

# Each theme: bg gradient (top, bottom), win and loss accent pairs (start, end).
THEMES = {
    "neon": {
        "bg": ((4, 12, 28), (8, 48, 62)),
        "win": ((70, 255, 195), (90, 190, 255)),
        "loss": ((255, 90, 115), (255, 160, 90)),
        "text": (240, 248, 255), "muted": (140, 168, 192), "ink": (6, 16, 30),
    },
    "gold": {
        "bg": ((8, 8, 10), (46, 32, 8)),
        "win": ((255, 218, 90), (255, 158, 28)),
        "loss": ((255, 96, 84), (190, 40, 64)),
        "text": (255, 246, 226), "muted": (178, 160, 124), "ink": (22, 14, 2),
    },
    "violet": {
        "bg": ((12, 6, 34), (66, 14, 92)),
        "win": ((110, 255, 225), (196, 122, 255)),
        "loss": ((255, 100, 150), (255, 176, 96)),
        "text": (246, 240, 255), "muted": (164, 148, 196), "ink": (14, 6, 34),
    },
    "frost": {
        "bg": ((10, 14, 24), (34, 48, 72)),
        "win": ((230, 246, 255), (110, 196, 255)),
        "loss": ((255, 150, 170), (255, 205, 205)),
        "text": (248, 251, 255), "muted": (150, 166, 190), "ink": (10, 16, 28),
    },
}


# ---------- small helpers ----------

def font(size):
    for name in ("segoeuib.ttf", "arialbd.ttf", "DejaVuSans-Bold.ttf"):
        try:
            return ImageFont.truetype(name, size)
        except OSError:
            continue
    return ImageFont.load_default()


def fit_font(draw, text, max_w, start):
    size = start
    while size > 24 and draw.textlength(text, font=font(size)) > max_w:
        size -= 6
    return font(size)


def hgradient(size, c1, c2):
    w, h = size
    mask = Image.linear_gradient("L").rotate(90, expand=True).resize((w, h))
    return Image.composite(Image.new("RGB", (w, h), c2), Image.new("RGB", (w, h), c1), mask)


def vgradient(size, c1, c2):
    w, h = size
    mask = Image.linear_gradient("L").resize((w, h))
    return Image.composite(Image.new("RGB", (w, h), c2), Image.new("RGB", (w, h), c1), mask)


def usd(v):
    v = float(v)
    for cut, suffix in ((1e9, "B"), (1e6, "M"), (1e3, "K")):
        if abs(v) >= cut:
            return f"${v / cut:,.2f}{suffix}"
    return f"${v:,.2f}"


def px(v):
    if abs(v) >= 100:
        return f"{v:,.2f}"
    if abs(v) >= 1:
        return f"{v:,.3f}"
    return f"{v:.6f}"


def sample_curve(up=True, n=48):
    """Stand-in PNL curve until we feed in real fills."""
    out, v = [], 0.0
    for i in range(n):
        v += (0.6 if up else -0.6) + math.sin(i * 0.9) * 1.1 + math.sin(i * 0.31) * 1.6
        out.append(v)
    return out


# ---------- drawing building blocks ----------

def glow(img, center, radius, color, strength=100):
    layer = Image.new("RGBA", img.size, (0, 0, 0, 0))
    x, y = center
    ImageDraw.Draw(layer).ellipse([x - radius, y - radius, x + radius, y + radius], fill=color + (strength,))
    img.alpha_composite(layer.filter(ImageFilter.GaussianBlur(radius * 0.6)))


def panel(img, box, radius=26, fill=(255, 255, 255, 16), outline=(255, 255, 255, 48)):
    layer = Image.new("RGBA", img.size, (0, 0, 0, 0))
    ImageDraw.Draw(layer).rounded_rectangle(box, radius=radius, fill=fill, outline=outline, width=2)
    img.alpha_composite(layer)


def paint_mask(img, mask, c1, c2, halo=0.5, blur=18):
    """Fill a shape (given as a mask) with a left-to-right gradient and a soft glow."""
    box = mask.getbbox()
    if not box:
        return
    x0, _, x1, _ = box
    if halo:
        haze = Image.new("RGBA", img.size, c1 + (0,))
        haze.putalpha(mask.filter(ImageFilter.GaussianBlur(blur)).point(lambda v: int(v * halo)))
        img.alpha_composite(haze)
    layer = Image.new("RGBA", img.size, (0, 0, 0, 0))
    layer.paste(hgradient((max(x1 - x0, 1), img.height), c1, c2), (x0, 0))
    img.paste(layer, (0, 0), mask)


def gradient_text(img, xy, text, fnt, c1, c2, halo=0.5, blur=18):
    mask = Image.new("L", img.size, 0)
    ImageDraw.Draw(mask).text(xy, text, font=fnt, fill=255)
    paint_mask(img, mask, c1, c2, halo, blur)


def pill(img, xy, text, fnt, c1, c2, ink):
    d = ImageDraw.Draw(img)
    w, h = int(d.textlength(text, font=fnt)) + 44, 48
    x, y = xy
    mask = Image.new("L", (w, h), 0)
    ImageDraw.Draw(mask).rounded_rectangle([0, 0, w - 1, h - 1], radius=h // 2, fill=255)
    img.paste(hgradient((w, h), c1, c2), (x, y), mask)
    d.text((x + 22, y + h // 2), text, font=fnt, fill=ink, anchor="lm")
    return w


def background(t, c1, c2):
    img = vgradient((W, H), *t["bg"]).convert("RGBA")
    glow(img, (W - 170, 40), 340, c1, 62)
    glow(img, (60, H - 30), 280, c2, 48)
    img.paste(hgradient((W, 4), c1, c2), (0, 0))  # shiny top edge
    return img


def header(img, t, c1, c2, label):
    d = ImageDraw.Draw(img)
    gradient_text(img, (70, 40), "PEPEX", font(38), c1, c2, halo=0.4, blur=9)
    f = font(20)
    d.text((W - 70, 54), label, font=f, fill=t["muted"], anchor="rm")


def stat(img, x, y, label, value, t, color=None):
    d = ImageDraw.Draw(img)
    d.text((x, y), label, font=font(19), fill=t["muted"])
    d.text((x, y + 30), value, font=font(38), fill=color or t["text"])


def stat_strip(img, t, items, color):
    panel(img, (70, 490, 1130, 588))
    for i, (label, value) in enumerate(items):
        stat(img, 104 + i * 350, 504, label, value, t, color if i == len(items) - 1 else None)


def place_mascot(img, path, c1, c2):
    """Returns the bottom edge of the mascot, or None if there is no mascot file."""
    try:
        m = Image.open(path).convert("RGBA")
    except FileNotFoundError:
        return None
    m.thumbnail((410, 230))
    x, y = 720 + (410 - m.width) // 2, 84
    glow(img, (x + m.width // 2, y + m.height // 2), 150, c1, 70)
    mask = Image.new("L", m.size, 0)
    ImageDraw.Draw(mask).rounded_rectangle([0, 0, m.width - 1, m.height - 1], radius=28, fill=255)
    img.paste(m, (x, y), mask)
    ring = Image.new("RGBA", img.size, (0, 0, 0, 0))
    ImageDraw.Draw(ring).rounded_rectangle([x, y, x + m.width, y + m.height], radius=28, outline=c1 + (230,), width=3)
    img.alpha_composite(ring)
    return y + m.height


def line_chart(img, box, values, c1, c2):
    x0, y0, x1, y1 = box
    panel(img, box)
    lo, hi = min(values), max(values)
    span = (hi - lo) or 1
    n = len(values) - 1
    top, bottom = y0 + 30, y1 - 22
    pts = [(x0 + 24 + i * (x1 - x0 - 48) / n, bottom - (v - lo) / span * (bottom - top)) for i, v in enumerate(values)]

    grid = Image.new("RGBA", img.size, (0, 0, 0, 0))
    gd = ImageDraw.Draw(grid)
    for k in range(4):
        gy = top + k * (bottom - top) / 3
        gd.line([(x0 + 20, gy), (x1 - 20, gy)], fill=(255, 255, 255, 20), width=1)
    img.alpha_composite(grid)

    area = Image.new("L", img.size, 0)
    ImageDraw.Draw(area).polygon(pts + [(pts[-1][0], bottom + 10), (pts[0][0], bottom + 10)], fill=255)
    ramp = ImageOps.invert(Image.linear_gradient("L").resize((x1 - x0, y1 - y0))).point(lambda v: int(v * 0.55))
    fade = Image.new("L", img.size, 0)
    fade.paste(ramp, (x0, y0))
    fill = Image.new("RGBA", img.size, c1 + (0,))
    fill.putalpha(ImageChops.multiply(area, fade))
    img.alpha_composite(fill)

    line = Image.new("L", img.size, 0)
    ImageDraw.Draw(line).line(pts, fill=255, width=5, joint="curve")
    paint_mask(img, line, c1, c2, halo=0.9, blur=10)

    ex, ey = pts[-1]
    glow(img, (ex, ey), 26, c2, 150)
    ImageDraw.Draw(img).ellipse([ex - 8, ey - 8, ex + 8, ey + 8], fill=(255, 255, 255), outline=c2, width=4)


# ---------- the cards ----------

def make_card(coin, side, leverage, roe, pnl, entry, exit_px, curve=None,
              theme="neon", mascot_path="mascot.png", path="card.png"):
    t = THEMES[theme]
    c1, c2 = t["win"] if pnl >= 0 else t["loss"]
    img = background(t, c1, c2)
    header(img, t, c1, c2, "PNL CARD")
    d = ImageDraw.Draw(img)

    pair = f"{coin} / USD"
    d.text((70, 118), pair, font=font(54), fill=t["text"])
    pill(img, (70 + int(d.textlength(pair, font=font(54))) + 26, 122), f"{side} {leverage}x", font(28), c1, c2, t["ink"])

    big = f"{roe:+.2f}%"
    gradient_text(img, (62, 232), big, fit_font(d, big, 620, 150), c1, c2, halo=0.55, blur=26)
    d.text((74, 392), "RETURN ON EQUITY", font=font(19), fill=t["muted"])

    bottom = place_mascot(img, mascot_path, c1, c2)
    top = 84 if bottom is None else bottom + 32
    line_chart(img, (720, top, 1130, 462), curve or sample_curve(pnl >= 0), c1, c2)

    stat_strip(img, t, [("ENTRY", px(entry)), ("EXIT", px(exit_px)), ("PNL (USD)", f"{pnl:+,.2f}")], c1)
    img.convert("RGB").save(path)


def make_volume_card(vol_24h, vol_7d, vol_30d, daily, trades=0, fees=0.0, labels=None,
                     theme="neon", path="volume.png"):
    t = THEMES[theme]
    c1, c2 = t["win"]
    img = background(t, c1, c2)
    header(img, t, c1, c2, "VOLUME CARD")
    d = ImageDraw.Draw(img)

    d.text((74, 128), "24H TRADING VOLUME", font=font(24), fill=t["muted"])
    big = usd(vol_24h)
    gradient_text(img, (62, 175), big, fit_font(d, big, 560, 150), c1, c2, halo=0.55, blur=26)

    x = 74
    for label, value in (("7D", usd(vol_7d)), ("30D", usd(vol_30d))):
        text = f"{label}   {value}"
        w = int(d.textlength(text, font=font(28))) + 44
        panel(img, (x, 372, x + w, 424), radius=26)
        d.text((x + 22, 398), label, font=font(28), fill=t["muted"], anchor="lm")
        d.text((x + 22 + d.textlength(label + "   ", font=font(28)), 398), value, font=font(28), fill=t["text"], anchor="lm")
        x += w + 18

    bx0, by0, bx1, by1 = 660, 84, 1130, 462
    panel(img, (bx0, by0, bx1, by1))
    labels = labels or ["6d", "5d", "4d", "3d", "2d", "1d", "Today"]
    n, hi = len(daily), max(daily) or 1
    slot = (bx1 - bx0 - 60) / n
    bw = int(slot * 0.56)
    base, ceiling = by1 - 52, by0 + 40
    for i, v in enumerate(daily):
        h = max(int((v / hi) * (base - ceiling)), 10)
        bx = int(bx0 + 30 + i * slot + (slot - bw) / 2)
        by = base - h
        last = i == n - 1
        mask = Image.new("L", (bw, h), 0)
        ImageDraw.Draw(mask).rounded_rectangle([0, 0, bw - 1, h + 12], radius=12, fill=255)
        if not last:
            mask = mask.point(lambda a: int(a * 0.5))
        else:
            glow(img, (bx + bw // 2, by + h // 2), 90, c1, 70)
        img.paste(vgradient((bw, h), c1, c2), (bx, by), mask)
        d.text((bx + bw // 2, base + 24), labels[i], font=font(18), fill=t["text"] if last else t["muted"], anchor="mm")

    avg = usd(vol_24h / trades) if trades else "-"
    stat_strip(img, t, [("TRADES (24H)", f"{trades:,}"), ("FEES PAID", usd(fees)), ("AVG TRADE SIZE", avg)], c1)
    img.convert("RGB").save(path)


if __name__ == "__main__":
    daily = [0.9e6, 1.4e6, 0.7e6, 1.8e6, 1.1e6, 1.5e6, 1.24e6]
    for name in THEMES:
        make_card("BTC", "LONG", 20, 10.27, 1280.50, 64250, 64580, theme=name, path=f"card_{name}.png")
        make_volume_card(1_240_000, 8_900_000, 31_200_000, daily, trades=128, fees=412.7,
                         theme=name, path=f"volume_{name}.png")
    print("Done. Open the card_*.png and volume_*.png files to compare styles.")
